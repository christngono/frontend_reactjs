import "bootstrap/dist/css/bootstrap.min.css"
import BannerSimple from "../../shared-components/BannerSimple/BannerSimple"

const Apropos = () => {
  return (
    <>
      <BannerSimple />
    </>
  )
}

export default Apropos
