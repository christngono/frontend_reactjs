import React from "react";
import Close from "../../assets/Vectorclose.svg";

export default function CloseButt() {
  return (
    <div>
      <img src={Close} />
    </div>
  );
}
