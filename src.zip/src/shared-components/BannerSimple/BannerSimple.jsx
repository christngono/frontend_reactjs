function BannerSimple() {
  return (
    <>
      <div className="navbar-lasylab navbar-light  bg-white">
        <a className="navbar-brand" href="#">
          <img src="./logo-lasylab.png" height="60" alt="" />
        </a>
      </div>
    </>
  )
}

export default BannerSimple
