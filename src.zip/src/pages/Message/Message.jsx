import "bootstrap/dist/css/bootstrap.min.css"
import MainBanner from "../../shared-components/MainBanner/MainBanner"
const Message = () => {
  return (
    <>
      <MainBanner />
      <div className="row d-flex justify-content-center align-items-center">
        <div className="col-md-6">
          <h1>poser toute vos questions , Bientôt disponible....</h1>
        </div>
      </div>
    </>
  )
}

export default Message
