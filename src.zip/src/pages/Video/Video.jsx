import React from "react"

const Video = () => {
  return <div></div>
}

export default Video
