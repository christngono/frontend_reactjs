import "bootstrap/dist/css/bootstrap.min.css"
import MainBanner from "../../shared-components/MainBanner/MainBanner"

function Reviser() {
  return (
    <>
      <MainBanner />
      <h1>nous revisons</h1>
    </>
  )
}

export default Reviser
